package com.project.booklnb.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.booklnb.dao.MemberDao;
import com.project.booklnb.model.Member;

@CrossOrigin
@RestController
public class MemberController {
	@Autowired
	MemberDao dao;
	
	@PostMapping("savemember")
	public Member saveMember(@RequestBody Member member) {
		System.out.println(member);
		return dao.saveMember(member);
	}
	
	@GetMapping(value="getmember/{email}")
	public Object getMemberByEmail(@PathVariable String email ){
		System.out.print(email);
		return dao.getMemberByEmail(email); 
	}
	
	@PutMapping(value="password/{email}/{newPassword}")
	public String updatePassword(@PathVariable String email, @PathVariable String newPassword){
		String s=dao.updatePassword(email,newPassword);
		return s;
	}
	
	@GetMapping("lentbyothers/{email}")
	public ArrayList<String> displayLentByOthers(@PathVariable String email) {
		return dao.displayLentByOthers(email);
	}
	
	@PostMapping("addBook/{email}/{Book}")
	public String addToBorrowedByUser(@PathVariable String email,@PathVariable String Book) {
		String ok=dao.addToBorrowedByUser(Book,email);
		return ok;
	}
	
	@PostMapping("removeBook/{lenderName}/{Book}")
	public String removeFromOriginalList(@PathVariable String lenderName,@PathVariable String Book) {
		String ok=dao.removeFromOriginalList(Book, lenderName);
		return ok;
	}
	
	@PostMapping("addbook/{email}/{title}/{author}/{format}/{condition}")
	public String addBookToBookLent(@PathVariable String email,
			@PathVariable String title,@PathVariable String author,
			@PathVariable String format,@PathVariable String condition) {
		String add=dao.addBookToBookLent(email, title, author, format, condition);
		return add;
	}
	
	@PostMapping("returnBook/{email}/{book}")
	public String returnBook(@PathVariable String email,@PathVariable String book) {
		String ret=dao.returnBook(email, book);
		return ret;
	}
	
	@GetMapping("borrowedbooks/{email}")
	public ArrayList<String> borrowedByMe(@PathVariable String email){
		return dao.borrowedByMe(email);
	}
	
	@GetMapping("lentbyme/{email}")
	public ArrayList<String> lentByMe(@PathVariable String email){
		return dao.lentByMe(email);
	}
	

@GetMapping("allmembers")
	public List<Member> allMembers(){
		return dao.allMembers();
	}


}
