package com.project.booklnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLnBApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookLnBApplication.class, args);
		System.out.println("Service is up");
	}

}
