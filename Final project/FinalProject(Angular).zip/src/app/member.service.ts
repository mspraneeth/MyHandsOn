import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Member } from './member.model';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private http:HttpClient) { }

  createMember(member:Member){
    return this.http.post<Member>('http://localhost:2222/savemember',member)
  }

  displayLentByOthers(email:string){
    return this.http.get<string[]>(`http://localhost:2222/lentbyothers/${email}`)
  }

  getMember(email:string){
    return this.http.get<Member>(`http://localhost:2222/getmember/${email}`);
  }

  addBorrowBook(email:string,book:string){
    return this.http.post<any>(`http://localhost:2222/addBook/${email}/${book}`,null);
  }
  removeBorrowBook(name:string,book:string){
    return this.http.post<any>(`http://localhost:2222/removeBook/${name}/${book}`,null);
  }

  addBookToBookLent(email:string,title:string,author:string,format:string,condition:string,){
    return this.http.post(`http://localhost:2222/addbook/${email}/${title}/${author}/${format}/${condition}`,null)
  }

  borrowedByMe(email:string){
    return this.http.get<string[]>(`http://localhost:2222/borrowedbooks/${email}`);
  }

  removeBorrowed(email:string,book:string){
    return this.http.post<any>(`http://localhost:2222/returnBook/${email}/${book}`,null);
  }

  lentByMe(email:string){
    return this.http.get<string[]>(`http://localhost:2222/lentbyme/${email}`);
  }

  changePassword(email:string,password:string){
    return this.http.put(`http://localhost:2222/password/${email}/${password}`,null)
  }

  allMembers(){
    return this.http.get<Member[]>('http://localhost:2222/allmembers');
  }

}
