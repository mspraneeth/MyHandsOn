import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LentbymeComponent } from './lentbyme.component';

describe('LentbymeComponent', () => {
  let component: LentbymeComponent;
  let fixture: ComponentFixture<LentbymeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LentbymeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LentbymeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
