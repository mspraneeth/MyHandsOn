import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'membername'
})
export class MemberNamePipe implements PipeTransform {

    str:string;
    str1:string[];
    transform(value: string) {
        this.str=value;
        this.str1=this.str.split(":");
        return this.str1[4];
    }

}