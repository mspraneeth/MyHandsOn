import { Component, OnInit } from '@angular/core';
import { MemberService } from 'src/app/member.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-addbooks',
  templateUrl: './addbooks.component.html',
  styleUrls: ['./addbooks.component.css']
})
export class AddbooksComponent implements OnInit {

  constructor(private daosrv:MemberService,private route:ActivatedRoute,private router:Router) { }
  email:string;
  title:string;
  author:string;
  format:string;
  condition:string;
  

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }
  }

  addbooks()
  {
    if(this.title==null||this.author==null||this.format==null||this.condition==null){
    alert("Please fill all fields");
    }
    else{
    this.email=localStorage.getItem("email");
    this.daosrv.addBookToBookLent(this.email,this.title,this.author,this.format,this.condition).subscribe(data=>console.log(data),
    error=>console.log(error)
    );
    alert('Book posted successfully...!');
    location.reload();
    }
  }

  logout(){
    localStorage.setItem("login","");
    location.reload();
  }

}