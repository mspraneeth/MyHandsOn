import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-borrowedbooks',
  templateUrl: './borrowedbooks.component.html',
  styleUrls: ['./borrowedbooks.component.css']
})
export class BorrowedbooksComponent implements OnInit {

  constructor(private daosrv:MemberService,private router:Router) { }

  email:string = localStorage.getItem('email');
  theList:any[];
  a:boolean;

  ngOnInit(): void {
    if(localStorage.getItem("login")==""){
      this.router.navigateByUrl('login')
    }else{
    this.daosrv.borrowedByMe(this.email).subscribe(
      data=>this.theList=data,
      error=>console.log(error)
    )}
  }

  removeBook(book){
    this.a=confirm('The book will be returned back to the lender.\nClick OK to confirm returning.')
    if(this.a == true){
    this.daosrv.removeBorrowed(this.email,book).subscribe(
      data=>console.log(data),
      error=>console.log(error)
    )
    location.reload()
    }
  }
 
  logout(){
    localStorage.setItem("login","");
    location.reload();
  }



}
