import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Member } from 'src/app/member.model';
import { MemberService } from 'src/app/member.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  constructor(private membserv:MemberService,private router:Router) { }

  member:Member={"email":"","name":"","password":"","securityQuestion":"","securityAnswer":"","residentialAddress":"","booksBorrowed":[],"booksLent":[]};

  ngOnInit(): void {
  }

  email:string;
  securityQuestion:string;
  securityAnswer:string;

  authenticate(){
    this.membserv.getMember(this.email).subscribe(
      data=>{this.member=data;
        if(this.email == null || this.securityQuestion == null || this.securityAnswer == null){
          alert('Please fill all fields')
        }
        else if(this.member == null){
          alert('Email Address does not exist');
        }else if(!(this.member.securityQuestion == this.securityQuestion)){
          alert('Wrong Security Question Selected')
        }else if(!(this.member.securityAnswer == this.securityAnswer)){
          alert('Security answer is incorrect')
        }else{
          localStorage.setItem("email",this.email);
          this.router.navigate(['login/forgotpassword/changepassword']);
        }
      }  
    );      
  }  
}
