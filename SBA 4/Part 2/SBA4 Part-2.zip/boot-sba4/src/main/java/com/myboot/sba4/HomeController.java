package com.myboot.sba4;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.myboot.sba4.dao.DxcUsersDao;
import com.myboot.sba4.model.DxcUsers;

@Controller
public class HomeController {
	
	
	@Autowired
	DxcUsersDao dao;
	
	
	@RequestMapping(value="/test")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping(value="/loginsuccesspage")
	public String loginPage(Model model,@ModelAttribute DxcUsers dxcUsers)
	{
		int userId=dxcUsers.getUserId();
		String password=dxcUsers.getPassword();
		DxcUsers dxcUsers2=dao.getUsersById(userId);
		if((userId==(dxcUsers2.getUserId())) && (password.equals(dxcUsers2.getPassword())))
		{
			return "loginsuccesspage";
		}
		
		else
		{
			
			return "loginfail";
		}
		
	}
	
	@RequestMapping(value="/forgetpasswordpage")
	public String forgetPassword()
	{
		return "forgetpasswordpage";
	}
	@RequestMapping(value="/changepasswordpage")
	public String forgetPassword(Model model,@ModelAttribute DxcUsers dxcUsers)
	{
		int userId=dxcUsers.getUserId();
		String userName=dxcUsers.getUserName();
		String securityQuestion=dxcUsers.getSecurityQuestion();
		String securityAnswer=dxcUsers.getSecurityAnswer();
		DxcUsers dxcUsers2=dao.getUsersById(userId);
		if((userId==(dxcUsers2.getUserId())) && (userName.equals(dxcUsers2.getUserName()))  && (securityQuestion.equals(dxcUsers2.getSecurityQuestion()))  &&  (securityAnswer.equals(dxcUsers2.getSecurityAnswer())) )
		{
			model.addAttribute("userId",userId);
			return "changepasswordpage";
		}
		else 
		{
			return "changepasswordfail";
		}
			
			
	}
	
	@RequestMapping(value="/changesuccesspage")
	public String changePassword(Model model,@ModelAttribute DxcUsers dxcUsers)
	{
		int userId=dxcUsers.getUserId();
		String password=dxcUsers.getPassword();
		String status=dao.updatePassword(userId, password);
		model.addAttribute("status",status);
		return "passwordupdatestatus";
	}
	
	
	@RequestMapping(value="/createstatuspage")
	public String saveUser(Model model,@ModelAttribute DxcUsers dxcUsers)
	{
		String status=dao.saveUsers(dxcUsers);
		model.addAttribute("status",status);
		return "createstatuspage";
		
	}
	
	@RequestMapping(value="/createuserpage")
	public String createUser()
	{
		return "createuserpage";
	}
	
	

}
