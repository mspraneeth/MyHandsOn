package com.myboot.sba4.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.aspectj.runtime.reflect.Factory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myboot.sba4.model.DxcUsers;





@Component
@Transactional
public class DxcUsersDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public DxcUsersDao() {
		// TODO Auto-generated constructor stub
	}

	public DxcUsersDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	public DxcUsers getUsersById(int userId){
		try{
		Session session=sessionFactory.getCurrentSession();
		DxcUsers dxcUsers=(DxcUsers)session.get(DxcUsers.class,userId);
		return dxcUsers;
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return null;
		}
	
	public String updatePassword(int userId, String password)
	{
		try
		{
			Session session=sessionFactory.getCurrentSession();
			Query query = session.createQuery("update DxcUsers set password = :password" +" where userId = :userId");
			query.setParameter("password",password);
			query.setParameter("userId",userId);
			int count=query.executeUpdate();
			if(count>0)
				return "password updated";
			
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "password cannot updated";

	}
	
	
	public String saveUsers(DxcUsers dxcUsers){
		try{
			Session session=sessionFactory.getCurrentSession();
			session.save(dxcUsers);
			return "user Created";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "cannot create user";
		}
	

}
