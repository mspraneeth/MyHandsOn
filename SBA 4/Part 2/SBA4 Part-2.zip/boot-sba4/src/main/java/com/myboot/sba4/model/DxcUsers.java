package com.myboot.sba4.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DxcUsers {
	
	@Id
	int userId;
	String userName;
	String password;
	String securityQuestion;
	String securityAnswer;
	
	
	public DxcUsers() {
		// TODO Auto-generated constructor stub
	}


	public DxcUsers(int userId, String userName, String password, String securityQuestion, String securityAnswer) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getSecurityQuestion() {
		return securityQuestion;
	}


	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}


	public String getSecurityAnswer() {
		return securityAnswer;
	}


	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}


	@Override
	public String toString() {
		return "DxcUsers [userId=" + userId + ", userName=" + userName + ", password=" + password
				+ ", securityQuestion=" + securityQuestion + ", securityAnswer=" + securityAnswer + "]";
	}
	
	
	
	

}
