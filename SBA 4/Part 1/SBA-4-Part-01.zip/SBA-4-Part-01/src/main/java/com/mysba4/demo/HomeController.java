package com.mysba4.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysba4.demo.dao.FacultyDao;
import com.mysba4.demo.model.Faculty;





@Controller
public class HomeController {
	
	@Autowired
	FacultyDao dao;
	
	@RequestMapping(value="/")
	public String home(Model model)
	{
	return "home";
	}
	
	@RequestMapping(value="/savefaculty")
	public String display(Model model,@ModelAttribute Faculty faculty)
	{
	String status=dao.saveFaculty(faculty);
	model.addAttribute("status",status);
	return "savefaculty";
	}
	
	@RequestMapping(value="/facultybyname")
	public String facultyByName(Model model,@RequestParam("facultyName") String facultyName)
	{
	ArrayList<Faculty> faculty=dao.getByName(facultyName);
	model.addAttribute("faculty",faculty);
	return "displayByName";
	}
	
	
	int facultyId=0;
	
	
	
	
	@RequestMapping(value="/facultybysubject")
	public String facultyBySubject(Model model,@RequestParam("facultySubject") String facultySubject)
	{
	ArrayList<Faculty> faculty=dao.getBySubject(facultySubject);
	model.addAttribute("faculty",faculty);
	return "displayByName";
	}
	
	
	@RequestMapping(value="/updatePage")
	public String update()
	{
	return "updatePage";
	}

	

	@RequestMapping(value="/searchForUpdate")
	public String searchForUpdate(Model model,@RequestParam("facultyId") String facultyId)
	{
	int authId=Integer.parseInt(facultyId);
	this.facultyId=authId;
	Faculty faculty=dao.getFacultyById(authId);
	model.addAttribute(faculty);
	return "updatePage";
	}


	@RequestMapping(value="/updateData")
	public String updateData(Model model, @ModelAttribute Faculty author)
	{
	author.setFacultyId(facultyId);
	String status=dao.updateFacultyById(author);
	model.addAttribute("status",status);
	return "updatefaculty";
	}
	
	@RequestMapping(value="/deleteByName")
	public String deleteByName(Model model,@RequestParam("facultyName") String facultyName)
	{
	String status=dao.deleteFaculty(facultyName);
	model.addAttribute("status",status);
	return "updatefaculty";
	}
}
