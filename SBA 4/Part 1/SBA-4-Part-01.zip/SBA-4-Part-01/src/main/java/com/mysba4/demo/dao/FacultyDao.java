package com.mysba4.demo.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.mysba4.demo.model.Faculty;




@Transactional
public class FacultyDao {
	
	@Autowired
	SessionFactory factory;
	
	public FacultyDao() {
		// TODO Auto-generated constructor stub
	}

	public FacultyDao(SessionFactory factory) {
		super();
		this.factory = factory;
	}
	
	public String saveFaculty(Faculty faculty){
		try{
		Session session=factory.getCurrentSession();
		session.save(faculty);
		return "faculty Created";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "cannot create faculty";
		}
	
	

	
	
	public ArrayList<Faculty> getByName(String facultyName){
		
		Session session=factory.openSession();
		
		Criteria ct=session.createCriteria(Faculty.class);
		ct.add(Restrictions.ilike("facultyName", facultyName));
		
		ArrayList<Faculty> faculty=(ArrayList<Faculty>) ct.list();
		
		return faculty;
			
	}
	
	
public ArrayList<Faculty> getBySubject(String facultySubject){
		
		Session session=factory.openSession();
		
		Criteria ct=session.createCriteria(Faculty.class);
		ct.add(Restrictions.ilike("facultySubject", facultySubject));
		
		ArrayList<Faculty> faculty=(ArrayList<Faculty>) ct.list();
		
		return faculty;
			
	}


public Faculty getFacultyById(int facultyId){
try{
Session session=factory.getCurrentSession();
Faculty faculty=(Faculty)session.get(Faculty.class,facultyId);
return faculty;
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return null;
}

public String updateFacultyById(Faculty faculty){
try{
Session session=factory.getCurrentSession();


session.update("Faculty",faculty);
return "Faculty Updated";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "Cannot Update Faculty";
}

public String deleteFaculty(String facultyName){
try{
Session session=factory.getCurrentSession();
Query query=session.createQuery("delete from Faculty f  where f.facultyName=:facultyname");
query.setParameter("facultyName", facultyName);
int count=query.executeUpdate();
if(count>0)
	return "Entry deleted";
}
catch (Exception e) {
// TODO: handle exception
e.printStackTrace();
}

return "cannot delete entry";
}

}
